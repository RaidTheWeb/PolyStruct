# Monkey

This repo is for ["Writing An Interpreter in Go"](https://interpreterbook.com/).

The book is really awesome! You should buy it ASAP!
